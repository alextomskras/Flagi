package dreamer.com.roomviewmodelkotlinsample

import android.content.Context
import android.support.v7.widget.RecyclerView
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import com.squareup.picasso.Picasso
import dreamer.com.roomviewmodelkotlinsample.Activity.MainActivity
import dreamer.com.roomviewmodelkotlinsample.Model.CountryModel
import kotlinx.android.synthetic.main.single_country_model_layout.*

class CountryRecyclerViewAdapter(_context : Context, _countryList:List<CountryModel>) : RecyclerView.Adapter<CountryRecyclerViewAdapter.CountryViewHolder>() {

    val context = _context
    val countryList = _countryList

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CountryViewHolder{
        val view = LayoutInflater.from(context).inflate(R.layout.single_country_model_layout,parent,false)
        return CountryViewHolder(view)
    }

    override fun getItemCount(): Int {
//        notifyDataSetChanged()
        return countryList.size
    }

    override fun onBindViewHolder(holder:CountryViewHolder, position: Int) {
        val country = countryList[position]

        holder.countryName.text = country.name
        holder.countryCapital.text = country.capital
        holder.countryPopulation.text = country.population.toString()
        val picturesUrl = country.flag
        Log.e(CountryRecyclerViewAdapter::class.java.simpleName,picturesUrl.toString())
        try {
//            Picasso.get()
////                        .load("$picturesUrl")
//                    .load("https://restcountries.eu/data/afg.svg")
//                    .fit()
//                    .into(holder.countryImage)
//        } catch (e: Exception) {
//            e.printStackTrace()
//        }
                    GlideApp.with(this@CurrentWeatherFragment)

                    .load(picTures)

//                    .load("https://assets.weatherstack.com/images/wsymbols01_png_64/wsymbol_0008_clear_sky_night.png")
                    .into(imageView_condition_icon)
//            Log.d(this.toString(), "fromListLisr with2 error code: ${it.conditionIconUrl}")

//        holder.countryImage = country.flag

    }


    class CountryViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView)
    {
        val countryName : TextView = itemView.findViewById(R.id.country_name)
        val countryCapital : TextView = itemView.findViewById(R.id.country_capital)
        val countryPopulation : TextView = itemView.findViewById(R.id.country_population)
        val countryImage : ImageView = itemView.findViewById(R.id.country_image)
    }

}